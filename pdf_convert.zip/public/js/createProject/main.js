var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab
var dirInform ="./Home/uploads/media";
var folder_dir =[];
var convertedPdfName =[];
var srcPdfFileArray = [];//convert php array to javascript array
var currentPdfPageIndex = 2 ;
var choosedData = [];
var currentFolder_dir ="";
